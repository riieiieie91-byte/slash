# PTJSCRIPT
Modern mobile-first static Lua Script Hub for GitHub Pages.

## Deploy on GitHub Pages
1. Create a repository named `PTJSCRIPT`.
2. Upload everything inside this folder to the repository root.
3. Settings → Pages → Deploy from branch → `main` → `/ (root)` → Save.
4. Open the GitHub Pages URL shown by GitHub.

This version is frontend-only. Login/Admin screens are UI demos and do not provide secure server-side authentication.
